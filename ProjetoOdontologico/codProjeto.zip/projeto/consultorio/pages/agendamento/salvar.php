<?php

if($_POST['idPaciente'] == '' && $_POST['idDentista'] == '' && $_POST['dataHora'] == '' 
    && $_POST['procedimento'] == '') {

    // header("Location: /projeto/consultorio/pages/dentista/listar.php");
    echo '<a href="http://localhost/projeto/consultorio/pages/agendamento/agendar.php">Campos devem ser preenchidos</a>';
    exit;
}

$idPaciente = $_POST['idPaciente'];
$idDentista = $_POST['idDentista'];
$dataHora = $_POST['dataHora'];
$procedimento = $_POST['procedimento'];

$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");

$queryInsert = " INSERT INTO agendamento (
        id_paciente, 
        id_dentista,  
        data_hora, 
        procedimento
    ) VALUES (?, ?, ?, ?)";

$stmt = $connection->prepare($queryInsert);

$stmt->bind_param(
    "ssss",
    $idPaciente,
    $idDentista,
    $dataHora,
    $procedimento);

$stmt->execute();

echo "Salvo com sucesso!";
echo "<br/>";
echo '<a href="http://localhost/projeto/consultorio/pages/agendamento/listar.php">Listar</a>';


?>