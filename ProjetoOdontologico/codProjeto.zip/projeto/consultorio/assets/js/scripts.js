
//PROVISORIO

tabelasDados = new Array();


	function openAjax() {
		var ajax;
		try {
			ajax = new XMLHttpRequest();
		} catch(ee) {
			try {
				ajax = new ActiveXObject("Msxm12.XMLHTTP");
			} catch(e) {
				try {
					ajax = new ActiveXObject("Microsoft.XMLHTTP");
				} catch(E) {
					ajax = false;
				}
			}
		}
		return ajax;
	}

	function abreFormulario(caminhoFormulario) {
		var carregandoCorpoFormulario = document.getElementById('carregandoCorpoFormulario');
		var areaFormulario = document.getElementById('areaFormulario');
		var ajax = openAjax();

		ajax.open("GET",caminhoFormulario,true);
		ajax.onreadystatechange = function() {
			if (ajax.readyState < 4) {
				areaFormulario.innerHTML = '<div class=\"carregandoCorpoFormulario\"><img src=\"img/carregandoCorpoFormulario.gif\"></div>';
			}
			if (ajax.readyState == 4) {
				if (ajax.status == 200) {
					areaFormulario.innerHTML = ajax.responseText;
					tabelasDados = new Array();
					executaScript(ajax.responseText);
				}
			}
		}
		ajax.send(null);
	}

	function executaScript(retornoFormulario) {
		var inicioExecucao = 0;
		while (inicioExecucao != -1) {
			inicioExecucao = retornoFormulario.indexOf('<script', inicioExecucao);
			if (inicioExecucao >= 0) {
				inicioExecucao = retornoFormulario.indexOf('>', inicioExecucao) + 1;
				var finalExecucao = retornoFormulario.indexOf('</script>', inicioExecucao);
				codigoFormulario = retornoFormulario.substring(inicioExecucao,finalExecucao);
				eval(codigoFormulario);
			}
		}
	}

	function expandeGrupo(tituloGrupo,grupoItens) {
		var grupoItens = document.getElementById(grupoItens);
		if (grupoItens.className == "grupoItensFechado"){
			tituloGrupo.style.backgroundImage = "url(img/grupoAberto.gif)";
			grupoItens.className = "grupoItensAberto";
		} else {
			tituloGrupo.style.backgroundImage = "url(img/grupoFechado.gif)";
			grupoItens.className = "grupoItensFechado";
		}
	}

	function abreAba(cabecalhoAbas,corpoAbas,tituloAba) {
		var cabecalhoAbas = document.getElementById(cabecalhoAbas).getElementsByTagName("div");
		var corpoAbas = document.getElementById(corpoAbas).getElementsByTagName("div");
		var identificacaoAba;
		var titulosAbas = new Array();
		var conteudosAbas = new Array();
		for (var i in cabecalhoAbas) {
			if (cabecalhoAbas[i].className == "tituloAbaAberta")
				cabecalhoAbas[i].className = "tituloAbaFechada";
			if (cabecalhoAbas[i].className == "tituloAbaFechada")
				titulosAbas.push(cabecalhoAbas[i]);
			if (tituloAba == titulosAbas[i])
				identificacaoAba = i;
		}
		for (var j in corpoAbas) {
			if (corpoAbas[j].className == "conteudoAbaAberta")
				corpoAbas[j].className = "conteudoAbaFechada";
			if (corpoAbas[j].className == "conteudoAbaFechada")
				conteudosAbas.push(corpoAbas[j]);
		}
		titulosAbas[identificacaoAba].className = "tituloAbaAberta";
		conteudosAbas[identificacaoAba].className = "conteudoAbaAberta";
	}

	function removeCaracteresEspeciais(campoFormulario) {
		var letrasAcentuadas = "�����������������������������������������abcdefghijklmn��opqrstuvxwy���z";
		var letrasConvertidas = "AAAAAAAAAAAEEEEEEEEIIIIIIIIOOOOOOOOUUUUCCABCDEFGHIJKLMNNNOPQRSTUVXWYYYYZ";
		var caracteresEspecias = /\'|\"|\!|\?|\#|\$|\%|\�|\&|\*|\(|\)|\+|\�|\�|\�|\�|\�|\�|\�|\||\�|\`|\~|\^|\{|\}|\[|\}|\�|\�|\�|\/|\\|\<|\>|\;|\:/g; //'"!?#$%�&*()+�������|�`~^{}[}���/\<>;:
		var valorCampo = campoFormulario.value;
		var i, posicaoTexto, caractereTexto;
		var valorCampoConvertido = "";
		for (i=0; i<valorCampo.length; i++) {
			caractereTexto = valorCampo.charAt(i);
			posicaoTexto = letrasAcentuadas.indexOf(caractereTexto);
			if (posicaoTexto > -1)
				valorCampoConvertido += letrasConvertidas.charAt(posicaoTexto);
			else
				valorCampoConvertido += valorCampo.charAt(i);
		}
		valorCampoConvertido = valorCampoConvertido.replace(caracteresEspecias,"");
		campoFormulario.value = valorCampoConvertido;
	}

	function selecionaRegistro(identificacaoTabelaDados,identificacaoRegistro) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		if (tabelasDados[tabelaDados] == null)
			tabelasDados[tabelaDados] = 1;
		var registroSelecionado = tabelasDados[tabelaDados];
		tabelaDados.rows[registroSelecionado].className = "";
		tabelaDados.rows[registroSelecionado].cells[0].className = "identificacaoRegistro";
		tabelaDados.rows[identificacaoRegistro].className = "registroSelecionado";
		tabelaDados.rows[identificacaoRegistro].cells[0].className = "identificacaoRegistroSelecionado";
		tabelasDados[tabelaDados] = identificacaoRegistro;
	}

	function excluiRegistro(identificacaoTabelaDados) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		var quantidadeRegistros = tabelaDados.rows.length;
		if (quantidadeRegistros == 1 || tabelasDados[tabelaDados] == null) {
			alert("Nenhum registro selecionado!");
			return false;
		} else {
			var confirmaExclusao = confirm("Deseja realmente excluir este registro?");
			if (confirmaExclusao) {
				tabelaDados.deleteRow(tabelasDados[tabelaDados]);

				var quantidadeRegistros = tabelaDados.rows.lengtproximoRegistro = tabelaDados.rows[1];h;
				if (quantidadeRegistros == 1)
					return false;
				var proximoRegistro = tabelaDados.rows[tabelasDados[tabelaDados]];
				if (proximoRegistro == null)
					proximoRegistro = tabelaDados.rows[1];
				document.getElementById(identificacaoTabelaDados).getElementsByTagName("tbody")[0].scrollTop = proximoRegistro.offsetTop-145;
				proximoRegistro.onclick();
			}
		}
	}

	function selecionaPrimeiroRegistro(identificacaoTabelaDados) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		var quantidadeRegistros = tabelaDados.rows.length;
		if (quantidadeRegistros == 1)
			return false;
		else
			var primeiroRegistro = tabelaDados.rows[1];
		tabelaDados.getElementsByTagName("tbody")[0].scrollTop = primeiroRegistro.offsetTop-(parseInt(tabelaDados.getElementsByTagName("tbody")[0].style.height)+2);
		primeiroRegistro.onclick();
	}

	function selecionaRegistroAnterior(identificacaoTabelaDados) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		var quantidadeRegistros = tabelaDados.rows.length;
		if (quantidadeRegistros == 1)
			return false;
		if (tabelasDados[tabelaDados] == null) {
			tabelasDados[tabelaDados] = quantidadeRegistros-1;
			var registroAnterior = tabelaDados.rows[tabelasDados[tabelaDados]];
		} else
			var registroAnterior = tabelaDados.rows[tabelasDados[tabelaDados]-1];
		if (registroAnterior.rowIndex == 0)
			registroAnterior = tabelaDados.rows[quantidadeRegistros-1];
		tabelaDados.getElementsByTagName("tbody")[0].scrollTop = registroAnterior.offsetTop-(parseInt(tabelaDados.getElementsByTagName("tbody")[0].style.height)+2);
		registroAnterior.onclick();
	}

	function selecionaProximoRegistro(identificacaoTabelaDados) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		var quantidadeRegistros = tabelaDados.rows.length;
		if (quantidadeRegistros == 1)
			return false;
		if (tabelasDados[tabelaDados] == null)
			tabelasDados[tabelaDados] = 0;
		else
			var proximoRegistro = tabelaDados.rows[tabelasDados[tabelaDados]+1];
		if (proximoRegistro == null)
			proximoRegistro = tabelaDados.rows[1];
		tabelaDados.getElementsByTagName("tbody")[0].scrollTop = proximoRegistro.offsetTop-(parseInt(tabelaDados.getElementsByTagName("tbody")[0].style.height)+2);
		proximoRegistro.onclick();
	}

	function selecionaUltimoRegistro(identificacaoTabelaDados) {
		var tabelaDados = document.getElementById(identificacaoTabelaDados);
		var quantidadeRegistros = tabelaDados.rows.length;
		if (quantidadeRegistros == 1)
			return false;
		else
			var ultimoRegistro = tabelaDados.rows[quantidadeRegistros-1];
		tabelaDados.getElementsByTagName("tbody")[0].scrollTop = ultimoRegistro.offsetTop-(parseInt(tabelaDados.getElementsByTagName("tbody")[0].style.height)+2);
		ultimoRegistro.onclick();
	}

	imagensCarregadas = new Image();
	enderecosImagens = new Array();
	enderecosImagens[0] = "img/carregandoCorpoFormulario.gif";
	var i = 0;
	for(i=0; i<=enderecosImagens.lenght-1; i++)
		imagensCarregadas.src = enderecosImagens[i];