<!DOCTYPE HTML>
<html lang="pt-br">

	<head>
		<title>Cadastro Paciente</title>
		<link rel="shortcut icon" href="images/favicon.png" type="images/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="stylesheet" href="../../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../../assets/css/noscript.css" /></noscript>
	</head>
	
	<body class="homepage is-preload">

		<div id="page-wrapper">	
			<div id="header">
				<nav id="nav">
					<ul>
						<li>Área de cadastro</li>
					</ul>
					<div id="linhaCampos" style="background-color: gray;">

						<form action="./salvar.php" method="post">

							<label>* Nome:</label>
							<input type="text" name="nome" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>* CPF:</label>
							<input type="text" name="cpf" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>* Data Nasc.:</label>
							<input type="date" name="dataNasc" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<br/>

							<label>* E-Mail:</label>
							<input type="email" name="email" class="inputcadastro" placeholder="abc@gmail.com" onKeyUp="removeCaracteresEspeciais(this);">
							
							<label>* Celular:</label>
							<input type="tel" name="celular" class="inputcadastro" placeholder="(61)999999999" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Sexo:</label>
							<input type="radio" checked class="inputcadastro" name="sexo" value="M">Masculino
							<input type="radio" class="inputcadastro" name="sexo" value="F">Feminino

							<br/>

							<label>Nome do Pai:</label>
							<input type="text" name="nomePai" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
							
							<label>Nome da Mãe:</label>
							<input type="text" name="nomeMae" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Estado Civil:</label>
							<select name="estadoCivi" class="inputcadastro">
								<option></option>
								<option value="SO">SOLTEIRO</option>
								<option value="CA">CASADO</option>
								<option value="SE">SEPARADO</option>
								<option value="DI">DIVORCIADO</option>
								<option value="VI">VIUVO</option>														
							</select>

							<br/>

							<label>Cidade:</label>
							<input type="text" name="cidade" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Estado:</label>
							<select name="estado" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
								<option></option>
								<option value="AC">AC</option>ACRE
								<option value="AL">AL</option>ALAGOAS
								<option value="AP">AP</option>AMAPA
								<option value="AM">AM</option>
								<option value="BA">BA</option>
								<option value="CE">CE</option>
								<option value="DF">DF</option>
								<option value="ES">ES</option>
								<option value="GO">GO</option>
								<option value="MA">MA</option>
								<option value="MT">MT</option>
								<option value="MS">MS</option>
								<option value="MG">MG</option>
								<option value="PA">PA</option>
								<option value="PB">PB</option>
								<option value="PR">PR</option>
								<option value="PE">PE</option>
								<option value="PI">PI</option>
								<option value="RJ">RJ</option>
								<option value="RN">RN</option>
								<option value="RS">RS</option>
								<option value="RO">RO</option>
								<option value="RR">RR</option>
								<option value="SC">SC</option>
								<option value="SP">SP</option>
								<option value="SE">SE</option>
								<option value="TO">TO</option>
							</select>

							<br/>

							<label>Endereço:</label>
							<input type="text" name="endereco" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Bairro:</label>
							<input type="text" name="bairro" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>CEP:</label>
							<input type="text" name="cep" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">


							<hr/>

							<div id="linhaBotoes">
								
								<a href="http://localhost/projeto/consultorio/pages/paciente/salvar.php" target="_self">
									<input class="botaoAcao" type="submit" value="Salvar">
								</a>

								<a href="http://localhost/projeto/consultorio/pages/paciente/listar.php" target="_self">
									<input class="botaoAcao" onClick="" type="button" value="Cancelar">
								</a>

							</div>

						</form>

					</div>
				</div>
			</div>
		</div>

	</body>
</html>