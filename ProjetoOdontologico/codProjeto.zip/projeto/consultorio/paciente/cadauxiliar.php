<!DOCTYPE HTML>
<html lang="pt-br">

	<head>
		<title>Login Auxíliar</title>
		<link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="index.html">
		<noscript><link rel="stylesheet" href="assets/js/scripts.JavaScript" /></noscript>
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>

	<body class="homepage is-preload">

		<div id="page-wrapper">
			<div id="header">
				<nav id="nav">
					<ul>
						<li><a href="index.html">Área de cadastro</a></li>
					</ul>
					<div id="linhaCampos">

						<form action="./cadauxiliarsave.php">

							<label>Nome:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Data Nasc.:</label>
							<input type="date" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>CRO:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<br/>

							<label>Nome do Pai:</label>
							<input type="text" class="inputcadastro" name="nomePai" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Nome da Mãe:</label>
							<input type="text" class="inputcadastro" name="nomeMae" onKeyUp="removeCaracteresEspeciais(this);">

							<br/>

							<label>Sexo:</label>
							<input type="radio" class="inputcadastro" name="sexo" id="sexoM" value="M">Masculino</input>
							<input type="radio" class="inputcadastro" name="sexo" id="sexoF" value="F">Feminino</input>

							<br/>

							<label>Estado Civil:</label>
							<select  class="inputcadastro">
								<option></option>
								<option value="SO">SOLTEIRO</option>
								<option value="CA">CASADO</option>
								<option value="SE">SEPARADO</option>
								<option value="DI">DIVORCIADO</option>
								<option value="VI">VIUVO</option>
							</select>

							<br/>

							<label>Nacionalidade:</label>
							<input type="text" class="inputcadastro">

							<label>Cidade:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Estado:</label>
							<select class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
								<option></option>
								<option value="AC">AC</option>ACRE
								<option value="AL">AL</option>ALAGOAS
								<option value="AP">AP</option>AMAPA
								<option value="AM">AM</option>
								<option value="BA">BA</option>
								<option value="CE">CE</option>
								<option value="DF">DF</option>
								<option value="ES">ES</option>
								<option value="GO">GO</option>
								<option value="MA">MA</option>
								<option value="MT">MT</option>
								<option value="MS">MS</option>
								<option value="MG">MG</option>
								<option value="PA">PA</option>
								<option value="PB">PB</option>
								<option value="PR">PR</option>
								<option value="PE">PE</option>
								<option value="PI">PI</option>
								<option value="RJ">RJ</option>
								<option value="RN">RN</option>
								<option value="RS">RS</option>
								<option value="RO">RO</option>
								<option value="RR">RR</option>
								<option value="SC">SC</option>
								<option value="SP">SP</option>
								<option value="SE">SE</option>
								<option value="TO">TO</option>
							</select>

							<br/>

							<label>Endereço:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>Bairro:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>CEP:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<br/>

							<label>Celular:</label>
							<input type="tel" class="inputcadastro" placeholder="(61)999999999" onKeyUp="removeCaracteresEspeciais(this);">

							<label>E-Mail:</label>
							<input type="email" class="inputcadastro" placeholder="abc@gmail.com" onKeyUp="removeCaracteresEspeciais(this);">

							<label>CPF:</label>
							<input type="text" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

						</form>

						<br/>

						<div id="linhaBotoes">
							<!--input class="botaoAcao" type="button" value="Novo"-->
							<input class="botaoAcao" type="button" value="Salvar">
							<!--input class="botaoAcao" type="button" value="Editar"-->
							<!-- input class="botaoAcao" type="button" value="Excluir" onClick="excluiRegistro('tabelaDadosCandidato');"-->
						</div>
						
					</div>

				</nav>
			</div>
		</div>
	</body>
</html>