<!DOCTYPE HTML>
<html lang="pt-br">

	<head>
		<title>Cadastro Dentista</title>
		<link rel="shortcut icon" href="images/favicon.png" type="images/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="stylesheet" href="../../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../../assets/css/noscript.css" /></noscript>
	</head>
	
	<body class="homepage is-preload">

		<div id="page-wrapper">	
			<div id="header">
				<nav id="nav">
					<ul>
						<li>Área de cadastro</li>
					</ul>
					<div id="linhaCampos" style="background-color: gray;">

						<form action="./salvar.php" method="post">

							<label>* Nome:</label>
							<input type="text" name="nome" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<label>* CRO:</label>
							<input type="text" name="cro" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							
							<br/>

							<label>* E-Mail:</label>
							<input type="email" name="email" class="inputcadastro" placeholder="abc@gmail.com" onKeyUp="removeCaracteresEspeciais(this);">
							
							<label>* Celular:</label>
							<input type="tel" name="celular" class="inputcadastro" placeholder="(61)999999999" onKeyUp="removeCaracteresEspeciais(this);">

							<br/>
													
						<label>Especialidade:</label>
						<select  name="especialidade" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
							<option value="AVALIACAO">Avaliação</option>
							<option value="CLINICO_GERAL">Clínico geral</option>
							<option value="ORTODONTIA">Ortodontia</option>
							<option value="ODONTOPEDIATRIA">Odontopediatria</option>
							<option value="IMPLANTODONTIA">Implantodontia</option>
							<option value="PROTESE">Prótese</option>
							<option value="PERIODONTIA">Periodontia</option>
							<option value="DENTISTICA">Dentística</option>
							<option value="EXODONTIA">Exodontia</option>
						</select>

						
						
						<hr/>

							<div id="linhaBotoes">
								
								<a href="http://localhost/projeto/consultorio/pages/dentista/salvar.php" target="_self">
									<input class="botaoAcao" type="submit" value="Salvar">
								</a>

								<a href="http://localhost/projeto/consultorio/pages/dentista/listar.php" target="_self">
									<input class="botaoAcao" onClick="" type="button" value="Cancelar">
								</a>

							</div>

						</form>

					</div>
				</div>
			</div>
		</div>

	</body>
</html>