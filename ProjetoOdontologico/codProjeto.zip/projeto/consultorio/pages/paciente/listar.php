<!DOCTYPE HTML>
<html lang="pt-br">
	<head>
		<title>Cadastro Paciente</title>
		<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="../../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../../assets/css/noscript.css" /></noscript>
	</head>

	<body class="homepage is-preload">
		<div id="page-wrapper">
			<div id="header">
				<nav id="nav">
					<ul>
						<li>Área do paciente</li>
					</ul>
					<div id="linhaCampos">

<table style="with: 100%; background-color: #f8f8f8; color: #000; font-size: 14px;">

	<thead>

		<tr style="border-bottom: 2px solid black;">
			<th>
				Nome
			</th>
			<th>
				CPF
			</th>
			<th>
				Data Nasc.
			</th>
			<th>
				Nome do Pai
			</th>
			<th>
				Nome da Mãe
			</th>
			<th>
				Sexo
			</th>
			<!--th>
				Estado Civil
			</th>
			<th>
				Cidade
			</th>
			<th>
				Estado
			</th>
			<th>
				Endereço
			</th>
			<th>
				Bairro
			</th-->
			<th>
				CEP
			</th>
			<th>
				Celular
			</th>
			<th>
				E-mail
			</th>
			<th>
				Ações
			</th>
		</tr>

	</thead>

	<tbody>

<?php

	$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");


	$querySelect = " SELECT id, nome, data_nasc, nome_pai, nome_mae, sexo, estado_civil, cidade, estado, endereco, bairro, cep, celular, email, cpf FROM paciente ORDER BY nome; ";

	$stmt = $connection->prepare($querySelect);

	$stmt->execute();

	$stmt->bind_result($id, 
		$nome, 
		$dataNasc, 
		$nomePai, 
		$nomeMae, 
		$sexo, 
		$estadoCivil, 
		$cidade, 
		$estado, 
		$endereco, 
		$bairro, 
		$cep, 
		$celular, 
		$email, 
		$cpf);


	while($stmt->fetch()) {

?>
	
		<tr style="border-bottom: 1px solid black;">

			<td>
				<?php echo $nome;?>
			</td>
			<td>
				<?php echo $cpf;?>
			</td>
			<td>
				<?php echo $dataNasc;?>
			</td>
			<td>
				<?php echo $nomePai;?>
			</td>
			<td>
				<?php echo $nomeMae;?>
			</td>
			<td>
				<?php echo $sexo;?>
			</td>
			<!--td>
				<?php echo $estadoCivil;?>
			</td-->
			<!--td>
				<?php echo $cidade;?>
			</td-->
			<!--td>
				<?php echo $estado;?>
			</td-->
			<!--td>
				<?php echo $endereco;?>
			</td-->
			<!--td>
				<?php echo $bairro;?>
			</td-->
			<td>
				<?php echo $cep;?>
			</td>
			<td>
				<?php echo $celular;?>
			</td>
			<td>
				<?php echo $email;?>
			</td>

			<td>
				<a href="http://localhost/projeto/consultorio/pages/paciente/excluir.php?id=<?php echo $id;?>" target="_self">
					[X]
				</a>
			</td>
		</tr>


		<?php
			}

			$connection->close();
			//fechar conexao
		?>

	</tbody>

</table>


					<div id="linhaBotoes">

						<a href="http://localhost/projeto/consultorio/pages/paciente/cadastrar.php" target="_self">
							<input class="botaoAcao" type="button" value="Novo">
						</a>

						<a href="http://localhost/projeto/consultorio/pages/index.html" target="_self">
							<input class="botaoAcao" onClick="" type="button" value="HOME">
						</a>

					</div>
				</div>
			</div>
		</div>
	</body>
</html>