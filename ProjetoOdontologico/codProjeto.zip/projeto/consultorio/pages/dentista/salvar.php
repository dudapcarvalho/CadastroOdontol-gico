<?php

if($_POST['nome'] == '' && $_POST['cro'] == '' && $_POST['email'] == '' 
    && $_POST['celular'] == '' && $_POST['especialidade'] == '') {

    // header("Location: /projeto/consultorio/pages/dentista/listar.php");
    echo '<a href="http://localhost/projeto/consultorio/pages/dentista/cadastrar.php">Campos devem ser preenchidos</a>';
    exit;
}

$nome = $_POST['nome'];
$cro = $_POST['cro'];
$email = $_POST['email'];
$celular = $_POST['celular'];
$especialidade = $_POST['especialidade'];

$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");

$queryInsert = " INSERT INTO dentista (
        nome, 
        cro, 
        email, 
        celular, 
        especialidade
    ) VALUES (?, ?, ?, ?, ?)";

$stmt = $connection->prepare($queryInsert);

$stmt->bind_param(
    "sssss",
    $nome,
    $cro,
    $email,
    $celular,
    $especialidade);

$stmt->execute();

echo "Salvo com sucesso!";
echo "<br/>";
echo '<a href="http://localhost/projeto/consultorio/pages/dentista/listar.php">Listar</a>';


?>