<!DOCTYPE HTML>
<html lang="pt-br">
	<head>
		<title>Agendamentos</title>
		<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="../../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../../assets/css/noscript.css" /></noscript>
	</head>

	<body class="homepage is-preload">
		<div id="page-wrapper">
			<div id="header">
				<nav id="nav">
					<ul>
						<li>Área de agendamento</li>
					</ul>
					<div id="linhaCampos">

<table style="with: 100%; background-color: #f8f8f8; color: #000; font-size: 14px;">

	<thead>

		<tr style="border-bottom: 2px solid black;">
			<th>
				Paciente
			</th>
			<th>
				Dentista
			</th>
			<th>
	           Horário
			</th>

			<th>
				Procedimento
			</th>
			
			
			<th>
				Ações
			</th>
		</tr>

	</thead>

	<tbody>

<?php

	$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");


	// $querySelect = " SELECT id, id_paciente, id_dentista, data_hora, procedimento FROM agendamento ORDER BY data_hora; ";

	$querySelect = "

SELECT a.id, 
	(select p.nome from paciente p where p.id = a.id_paciente) as nome_paciente, 
	(select d.nome from dentista d where d.id = a.id_dentista) as nome_dentista, 
	a.data_hora, 
	a.procedimento 
FROM agendamento a ORDER BY data_hora;

";

	$stmt = $connection->prepare($querySelect);

	$stmt->execute();

	$stmt->bind_result($id, 
		$nomePaciente, 
		$nomeDentista, 
		$dataHora,  
		$procedimento);


	while($stmt->fetch()) {

?>
	
		<tr style="border-bottom: 1px solid black;">

			<td>
				<?php echo $nomePaciente;?>
			</td>
			<td>
				<?php echo $nomeDentista;?>
			</td>
			<td>
				<?php echo $dataHora;?>
			</td>	
			<td>
				<?php echo $procedimento;?>
			</td>	

			<td>
				<a href="http://localhost/projeto/consultorio/pages/agendamento/excluir.php?id=<?php echo $id;?>" target="_self">
					[X]
				</a>
			</td>
		</tr>


		<?php
			}

			$connection->close();
			//fechar conexao
		?>

	</tbody>

</table>


					<div id="linhaBotoes">

						<a href="http://localhost/projeto/consultorio/pages/agendamento/agendar.php" target="_self">
							<input class="botaoAcao" type="button" value="Novo">
						</a>

						<a href="http://localhost/projeto/consultorio/pages/index.html" target="_self">
							<input class="botaoAcao" onClick="" type="button" value="HOME">
						</a>

					</div>
				</div>
			</div>
		</div>
	</body>
</html>