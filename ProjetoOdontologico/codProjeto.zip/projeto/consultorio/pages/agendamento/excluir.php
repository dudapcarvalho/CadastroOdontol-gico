
<?php

$id = $_GET['id'];

$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");

$queryDelete = "DELETE FROM agendamento WHERE id = $id";

$connection->query($queryDelete);

$connection->close();


echo "Excluído com sucesso!";
echo "<br/>";
echo '<a href="http://localhost/projeto/consultorio/pages/agendamento/listar.php">Listar</a>';


?>