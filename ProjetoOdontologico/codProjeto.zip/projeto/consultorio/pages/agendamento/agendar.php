<!DOCTYPE HTML>
<html lang="pt-br">

	<head>
		<title>Agendamentos</title>
		<link rel="shortcut icon" href="images/favicon.png" type="images/x-icon"/>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="stylesheet" href="../../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../../assets/css/noscript.css" /></noscript>
	</head>
	
	<body class="homepage is-preload">

		<div id="page-wrapper">	
			<div id="header">
				<nav id="nav">
					<ul>
						<li>Área de agendamento</li>
					</ul>
					<div id="linhaCampos" style="background-color: gray;">

						<form action="./salvar.php" method="post">

							<!-- combo paciente -->
							<label>Nome do paciente:</label>
							<select name="idPaciente" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
							<?php
								$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");
								$querySelect = " SELECT id, nome FROM paciente a ORDER BY nome;";
								$stmt = $connection->prepare($querySelect);
								$stmt->execute();
								$stmt->bind_result($id, $nome);
								while($stmt->fetch()) {

							?>
								<option value="<?php echo $id;?>"><?php echo $nome;?></option>
							<?php
								}
								$connection->close();
							?>
							</select>

							<br/>

							<!-- combo paciente -->
							<label>Nome do dentista:</label>
							<select name="idDentista" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">
							<?php
								$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");
								$querySelect = " SELECT id, nome FROM dentista ORDER BY nome;";
								$stmt = $connection->prepare($querySelect);
								$stmt->execute();
								$stmt->bind_result($id, $nome);
								while($stmt->fetch()) {
							?>
								<option value="<?php echo $id;?>"><?php echo $nome;?></option>
							<?php
								}
								$connection->close();
							?>
							</select>

							<br/>

						<label>Data e hora:</label>
						<input type="datetime-local" name="dataHora" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

						<br/>

						<label>Procedimento:</label>
						<select name="procedimento" class="inputcadastro" onKeyUp="removeCaracteresEspeciais(this);">

							<option value="AVALIACAO">Avaliação</option>
							<option value="CLINICO_GERAL">Clínico geral</option>
							<option value="ORTODONTIA">Ortodontia</option>
							<option value="ODONTOPEDIATRIA">Odontopediatria</option>
							<option value="IMPLANTODONTIA">Implantodontia</option>
							<option value="PROTESE">Prótese</option>
							<option value="PERIODONTIA">Periodontia</option>
							<option value="DENTISTICA">Dentística</option>
							<option value="EXODONTIA">Exodontia</option>
						</select>


						<hr/>

							<div id="linhaBotoes">
								
								<a href="http://localhost/projeto/consultorio/pages/agendamento/salvar.php" target="_self">
									<input class="botaoAcao" type="submit" value="Salvar">
								</a>

								<a href="http://localhost/projeto/consultorio/pages/agendamento/listar.php" target="_self">
									<input class="botaoAcao" onClick="" type="button" value="Cancelar">
								</a>

							</div>

						</form>

					</div>
				</div>
			</div>
		</div>

	</body>
</html>