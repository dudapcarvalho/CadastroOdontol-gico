<?php

if($_POST['nome'] == '' && $_POST['dataNasc'] == '' && $_POST['cpf'] == '' 
    && $_POST['celular'] == '' && $_POST['email'] == '') {

    // header("Location: /projeto/consultorio/pages/paciente/listar.php");
    echo '<a href="http://localhost/projeto/consultorio/pages/paciente/cadastrar.php">Campos devem ser preenchidos</a>';
    exit;
}

$nome = $_POST['nome'];
$dataNasc = $_POST['dataNasc'];
$nomePai = $_POST['nomePai'];
$nomeMae = $_POST['nomeMae'];
$sexo = $_POST['sexo'];
$estadoCivil = $_POST['estadoCivi'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$endereco = $_POST['endereco'];
$bairro = $_POST['bairro'];
$cep = $_POST['cep'];
$celular = $_POST['celular'];
$email = $_POST['email'];
$cpf = $_POST['cpf'];

$connection = new mysqli("localhost", "root", "", "consultorio") or die("Problema ao conectar no banco de dados mysql");

$queryInsert = " 
    INSERT INTO paciente (
        nome, 
        data_nasc, 
        nome_pai, 
        nome_mae, 
        sexo, 
        estado_civil, 
        cidade, 
        estado, 
        endereco, 
        bairro, 
        cep, 
        celular, 
        email, 
        cpf
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $connection->prepare($queryInsert);

$stmt->bind_param(
    "ssssssssssssss",
    $nome,
    $dataNasc,
    $nomePai,
    $nomeMae,
    $sexo,
    $estadoCivil,
    $cidade,
    $estado,
    $endereco,
    $bairro,
    $cep,
    $celular,
    $email,
    $cpf);

$stmt->execute();

echo "Salvo com sucesso!";
echo "<br/>";
echo '<a href="http://localhost/projeto/consultorio/pages/paciente/listar.php">Listar</a>';


?>